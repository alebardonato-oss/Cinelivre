# CineLivre v4 — Catálogo e fontes (versão 0.5.0)

Projeto Android independente em Kotlin, com interface em português e reprodução por Media3/ExoPlayer.

## Novidades nesta etapa
- Cada obra do catálogo demonstra a página de origem oficial; resultados do Internet Archive ganham botão para abrir a página do item e conferir detalhes/licença.
- Favoritos são identificados pela URL do vídeo, reduzindo colisões entre títulos iguais.
- A consulta online limita a busca textual e remove caracteres de consulta especiais antes de montar a pesquisa.
- Mantém catálogo de demonstração, busca, filtros, favoritos locais e reprodução.

## Como abrir
1. Extraia o ZIP.
2. Abra a pasta `CineLivre_Android_v4` no Android Studio recente.
3. Aguarde a sincronização do Gradle e execute em aparelho/emulador Android com acesso à internet.
4. Toque em **Explorar catálogo online autorizado** para pesquisar no Internet Archive.

## Limitações e segurança
- Este ZIP contém **código-fonte**, não um APK instalável.
- A versão não foi compilada nem testada num dispositivo nesta sessão.
- O aplicativo usa um campo de licença declarado pela plataforma para filtrar resultados; isso não é uma validação jurídica definitiva. Confira a página de cada obra e seus termos antes de reutilizar ou redistribuir.
- A busca atual cobre apenas o Internet Archive e tenta localizar arquivos MP4/WebM; nem todo item terá arquivo reproduzível, e os resultados podem ser lentos porque a aplicação consulta metadados individuais.
- Qualidade máxima, idioma e legendas dependem dos arquivos e metadados publicados pela fonte. Não se promete 4K em obras que não o oferecem.
- Não contorna DRM, não acessa catálogos pagos e não incorpora código, marca ou conteúdo protegido de outros aplicativos.
- O projeto procura manter o uso gratuito para quem assiste; hospedagem, publicação e manutenção podem gerar custos para quem opera o serviço.

## Tecnologias
- Kotlin / Android SDK
- AndroidX Media3 ExoPlayer
- Internet Archive Advanced Search e Metadata APIs
- Favoritos locais com SharedPreferences
