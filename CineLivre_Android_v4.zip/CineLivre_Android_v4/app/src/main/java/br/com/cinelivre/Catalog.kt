package br.com.cinelivre

data class Film(
    val title: String,
    val description: String,
    val category: String,
    val attribution: String,
    val videoUrl: String,
    val subtitleUrl: String? = null,
    val sourcePageUrl: String? = null
)

object Catalog {
    val films = listOf(
        Film(
            title = "Big Buck Bunny",
            description = "Curta de animação da Blender Foundation.",
            category = "Animação / Comédia",
            attribution = "© 2008 Blender Foundation • bigbuckbunny.org • Creative Commons Attribution 3.0",
            videoUrl = "https://download.blender.org/peach/bigbuckbunny_movies/BigBuckBunny_320x180.mp4",
            sourcePageUrl = "https://peach.blender.org/"
        ),
        Film(
            title = "Sintel",
            description = "Curta de fantasia produzido pela Blender Foundation.",
            category = "Fantasia",
            attribution = "© Blender Foundation • durian.blender.org • Creative Commons Attribution 3.0",
            videoUrl = "https://download.blender.org/durian/movies/sintel-2048-surround.mp4",
            sourcePageUrl = "https://durian.blender.org/"
        )
    )
}
