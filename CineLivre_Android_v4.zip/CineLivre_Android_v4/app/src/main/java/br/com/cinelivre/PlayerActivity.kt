package br.com.cinelivre

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@UnstableApi
class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra("title") ?: "Reprodutor"
        val url = intent.getStringExtra("videoUrl")
        val subtitle = intent.getStringExtra("subtitleUrl")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(15, 18, 27))
        }
        root.addView(TextView(this).apply {
            text = title
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(4, 8, 4, 12)
        })
        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(playerView)
        setContentView(root)
        if (url.isNullOrBlank()) {
            Toast.makeText(this, "Este título ainda não tem URL de vídeo.", Toast.LENGTH_LONG).show()
            return
        }
        val item = MediaItem.Builder().setUri(url).apply {
            if (!subtitle.isNullOrBlank()) {
                setSubtitleConfigurations(listOf(
                    MediaItem.SubtitleConfiguration.Builder(android.net.Uri.parse(subtitle))
                        .setMimeType(MimeTypes.TEXT_VTT)
                        .setLanguage("pt")
                        .setLabel("Português")
                        .build()
                ))
            }
        }.build()
        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
            it.setMediaItem(item)
            it.prepare()
            it.playWhenReady = true
        }
    }

    override fun onStop() {
        super.onStop()
        playerView.player = null
        player?.release()
        player = null
    }
}
