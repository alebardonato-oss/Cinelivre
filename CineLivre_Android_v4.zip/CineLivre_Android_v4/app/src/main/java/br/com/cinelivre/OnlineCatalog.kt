package br.com.cinelivre

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/** Busca itens do Internet Archive e só aceita resultados com licença declarada compatível. */
object OnlineCatalog {
    fun search(query: String = ""): List<Film> {
        val cleanQuery = query.trim().replace(Regex("""[+\-!(){}\[\]^"~*?:\\]"""), " ").replace(Regex("\\s+"), " ").take(80)
        val queryText = if (cleanQuery.isBlank()) {
            "mediatype:movies AND licenseurl:*creativecommons.org*"
        } else {
            "mediatype:movies AND licenseurl:*creativecommons.org* AND title:(${cleanQuery})"
        }
        val encodedQuery = URLEncoder.encode(queryText, "UTF-8").replace("+", "%20")
        val api = "https://archive.org/advancedsearch.php?q=$encodedQuery&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=description&fl%5B%5D=licenseurl&rows=20&page=1&output=json"
        val root = JSONObject(get(api))
        val docs = root.optJSONObject("response")?.optJSONArray("docs") ?: return emptyList()
        val found = mutableListOf<Film>()
        for (i in 0 until docs.length()) {
            val item = docs.optJSONObject(i) ?: continue
            val id = item.optString("identifier")
            val title = item.optString("title", id).takeIf { it.isNotBlank() } ?: id
            val license = item.optString("licenseurl")
            if (id.isBlank() || !(license.contains("creativecommons.org", true) || license.contains("publicdomain", true))) continue
            try {
                val metadata = JSONObject(get("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}"))
                val files = metadata.optJSONArray("files") ?: continue
                var videoPath: String? = null
                for (j in 0 until files.length()) {
                    val file = files.optJSONObject(j) ?: continue
                    val name = file.optString("name")
                    val format = file.optString("format")
                    val source = file.optString("source")
                    if (source == "original" && (name.endsWith(".mp4", true) || name.endsWith(".webm", true)) &&
                        (format.contains("MPEG4", true) || format.contains("WebM", true) || name.endsWith(".mp4", true) || name.endsWith(".webm", true))) {
                        videoPath = name
                        break
                    }
                }
                val video = videoPath ?: continue
                val safeId = URLEncoder.encode(id, "UTF-8")
                val safeFile = video.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                val desc = item.optString("description", "Obra disponível no Internet Archive.")
                    .replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").take(260)
                found.add(Film(title, desc.ifBlank { "Obra disponível no Internet Archive." }, "Catálogo online",
                    "Internet Archive • licença declarada: $license", "https://archive.org/download/$safeId/$safeFile",
                    sourcePageUrl = "https://archive.org/details/$safeId"))
            } catch (_: Exception) { /* item individual indisponível: ignora e continua */ }
        }
        return found
    }

    private fun get(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 12000
        connection.readTimeout = 18000
        connection.setRequestProperty("User-Agent", "CineLivre/0.5 (Android; open-catalogue)")
        return try {
            if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { connection.disconnect() }
    }
}
