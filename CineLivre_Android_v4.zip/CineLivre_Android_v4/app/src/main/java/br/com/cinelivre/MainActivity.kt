package br.com.cinelivre

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 15, 24)
    private val panel = Color.rgb(28, 34, 48)
    private val accent = Color.rgb(111, 168, 255)
    private val white = Color.WHITE
    private val muted = Color.LTGRAY
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var selectedCategory = "Todos"
    private var favoritesOnly = false
    private var onlineMode = false
    private var onlineFilms: List<Film> = emptyList()
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val favorites by lazy { getSharedPreferences("cinelivre", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 12)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "CineLivre"
            textSize = 30f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Cinema gratuito • fontes abertas e autorizadas"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, 4, 0, 14)
        })
        root.addView(Button(this).apply {
            text = "Voltar ao catálogo inicial"
            setOnClickListener { onlineMode = false; onlineFilms = emptyList(); render() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        search = EditText(this).apply {
            hint = "Buscar filme ou categoria"
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(14, 8, 14, 8)
            setBackgroundColor(panel)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Todos", "Animação", "Fantasia", "Favoritos").forEach { category ->
            filters.addView(Button(this).apply {
                text = category
                textSize = 11f
                setOnClickListener {
                    favoritesOnly = category == "Favoritos"
                    selectedCategory = if (favoritesOnly) "Todos" else category
                    render()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 })
        }
        root.addView(filters)
        root.addView(Button(this).apply {
            text = "Explorar catálogo online autorizado"
            setOnClickListener { loadOnlineCatalog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6; bottomMargin = 4 })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 10, 0, 8) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "INÍCIO     CATÁLOGO     MINHA LISTA"
            textSize = 12f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 6)
        })
        setContentView(root)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        render()
    }

    private fun loadOnlineCatalog() {
        val query = if (::search.isInitialized) search.text.toString().trim() else ""
        Toast.makeText(this, "Consultando o Internet Archive…", Toast.LENGTH_SHORT).show()
        networkExecutor.execute {
            try {
                val result = OnlineCatalog.search(query)
                runOnUiThread {
                    onlineFilms = result
                    onlineMode = true
                    selectedCategory = "Todos"
                    favoritesOnly = false
                    render()
                    Toast.makeText(this, "${result.size} títulos encontrados", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Não foi possível carregar o catálogo. Verifique a internet e tente novamente.", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        networkExecutor.shutdownNow()
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val query = if (::search.isInitialized) search.text.toString().trim() else ""
        val source = if (onlineMode) onlineFilms else Catalog.films
        val filtered = source.filter { film ->
            val matchesQuery = query.isBlank() || "${film.title} ${film.category} ${film.description}".contains(query, true)
            val matchesCategory = selectedCategory == "Todos" || film.category.contains(selectedCategory, true)
            val isFavorite = favorites.getBoolean(favoriteKey(film), false)
            matchesQuery && matchesCategory && (!favoritesOnly || isFavorite)
        }
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (onlineMode) "Nenhuma obra licenciada encontrada. Tente outra busca ou volte ao catálogo inicial." else "Nenhum título encontrado. Use o botão para explorar o catálogo online autorizado."
                textSize = 15f; setTextColor(muted); setPadding(8, 18, 8, 18)
            })
            return
        }
        filtered.forEach { film ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(panel)
                setPadding(14, 14, 14, 12)
            }
            card.addView(TextView(this).apply {
                text = film.title
                textSize = 20f; setTextColor(white); setTypeface(null, android.graphics.Typeface.BOLD)
            })
            card.addView(TextView(this).apply {
                text = "${film.category}\n${film.description}\n\nFonte/licença: ${film.attribution}"
                textSize = 13f; setTextColor(muted); setPadding(0, 7, 0, 8)
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply {
                text = "▶ Assistir"
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, PlayerActivity::class.java).apply {
                        putExtra("title", film.title)
                        putExtra("videoUrl", film.videoUrl)
                        putExtra("subtitleUrl", film.subtitleUrl)
                    })
                }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 })
            val isFavorite = favorites.getBoolean(favoriteKey(film), false)
            actions.addView(Button(this).apply {
                text = if (isFavorite) "★ Na minha lista" else "☆ Minha lista"
                setOnClickListener {
                    favorites.edit().putBoolean(favoriteKey(film), !favorites.getBoolean(favoriteKey(film), false)).apply()
                    Toast.makeText(this@MainActivity, if (!isFavorite) "Adicionado à Minha Lista" else "Removido da Minha Lista", Toast.LENGTH_SHORT).show()
                    render()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(actions)
            val sourceUrl = film.sourcePageUrl
            if (!sourceUrl.isNullOrBlank()) {
                card.addView(Button(this).apply {
                    text = "Ver fonte, licença e detalhes"
                    setOnClickListener {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(sourceUrl))) }
                        catch (_: Exception) { Toast.makeText(this@MainActivity, "Não foi possível abrir a página da fonte.", Toast.LENGTH_SHORT).show() }
                    }
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 4 })
            }
            list.addView(card, ViewGroup.LayoutParams(-1, -2))
            val spacer = TextView(this).apply { text = " "; textSize = 5f }
            list.addView(spacer)
        }
    }

    private fun favoriteKey(film: Film): String = "favorite:" + film.videoUrl

}
